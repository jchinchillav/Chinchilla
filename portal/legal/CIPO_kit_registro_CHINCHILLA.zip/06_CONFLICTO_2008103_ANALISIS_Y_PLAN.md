# Conflicto 2008103 "Chinchilla Design" (TMA1129774): hechos, opciones y plan

Preparado el 18 de octubre de 2026 a partir de la ficha oficial de CIPO (`CIPO_ficha_2008103_TMA1129774.pdf`). No es asesoría legal; la vía recomendada se ejecuta con un agente de marcas.

## 1. Hechos de la ficha

| Campo | Dato |
|---|---|
| Marca | "Chinchilla Design" (marca figurativa). Vienna: 3.5.7 roedores (silueta estilizada, de pie, personificado) + 24.9 una corona con esferas y representación de animal. Es decir: la palabra Chinchilla con un roedor coronado. |
| Nº solicitud / registro | 2008103 / TMA1129774 |
| Presentada | 24 de enero de 2020 |
| Registrada | 25 de mayo de 2022 (vence 25 de mayo de 2032) |
| Estado | REGISTERED · LIVE/REGISTRATION/Issued and Active |
| Titular | Khaldoun Alchaar, 127 Westminster Ave, Toronto, ON M6R 1N6 (persona física) |
| Agente | Jonathan Mesiano-Crookston, 1220-18 King St E, Toronto (Goldman Hine LLP) |
| Clase 25 | Baseball caps and hats; casual clothing; long sleeve shirts; polo shirts; sweaters; t-shirts |
| Clase 35 | Online sales of clothing |
| Examen | Sin informes de examen ni oposición; aprobada en el primer paso (feb 2022), publicada marzo 2022, registrada mayo 2022 |

**Corrección importante tras ver la imagen real (`CIPO_diseno_registrado_2008103.png`):** la marca registrada es **únicamente una silueta negra de roedor (tipo hámster, de pie) con una corona de cinco puntas**. **No contiene la palabra "Chinchilla"** ni ningún texto (sus códigos Vienna son solo de animales y coronas; no hay códigos de letras). "Chinchilla Design" es el nombre descriptivo que CIPO asigna al expediente.

## 2. Qué significa para Chinchilla (revisado con la imagen real)

- Productos y servicios: solapamiento total (gorras, sudaderas, camisetas; venta en línea).
- Parecido de las marcas, que es el factor de mayor peso según la Corte Suprema (Masterpiece, 2011): 
  - **Marca nominativa CHINCHILLA vs silueta sin texto:** no hay parecido en apariencia ni en sonido. Solo podría alegarse parecido en la "idea sugerida" (un chinchilla). La silueta registrada parece más un hámster que una chinchilla, y lleva corona. **Probabilidad de que el examinador la cite: baja a media. Probabilidad de superar la objeción si la cita: alta.**
  - **Nuestro isotipo (chinchilla sentada con cola de hoja) vs silueta de roedor coronado:** ambas son siluetas de roedor en ropa. Diferencias: postura (sentada vs de pie), cola de hoja (nuestro elemento distintivo), ojo, oreja y trazo geométrico vs silueta orgánica, sin corona. **Probabilidad de cita: media. Probabilidad de superarla: media-alta**, argumentando que la idea "roedor" no es monopolizable y que los rasgos distintivos difieren (corona vs hoja).
- Conclusión: la marca ajena **no bloquea** presentar; sí es un riesgo de informe de examen, sobre todo para el isotipo. La cancelación por no uso (art. 45) deja de ser prerrequisito y pasa a ser la herramienta de respaldo para eliminar el riesgo del todo, incluido el camino internacional.
- A favor nuestro: el registro cumplió **3 años el 25 de mayo de 2026**. Desde esa fecha cualquier persona puede pedir al Registrador que envíe al titular un **aviso del artículo 45** (cancelación por no uso). El titular tiene 3 meses para probar con declaración jurada que usó la marca en Canadá, con esos productos y servicios, en los 3 años anteriores al aviso. Si no responde, el registro se cancela; si prueba uso parcial, se recorta a lo probado.
- Señales de no uso (a confirmar): no aparece ninguna tienda, Instagram, Shopify, Etsi ni mención de una marca de ropa "Chinchilla" de Toronto en búsquedas web del 18 oct 2026. El titular es una persona física, no una empresa. La ficha no muestra cambios desde 2022.

## 3. Opciones

| # | Vía | Cómo | Costo gubernamental | Costo agente (típico) | Tiempo | Riesgo |
|---|---|---|---|---|---|---|
| A (recomendada) | **Artículo 45, cancelación por no uso** | Solicitud escrita al Registrador citando TMA1129774 + tasa. Puede presentarla el agente sin revelar quién está detrás más allá del solicitante. | ≈ CAD 595.06 (2026, cifra de fuentes secundarias; confirmar en la tabla oficial de tasas de CIPO) | CAD 1,500-3,000 si el titular no responde; más si presenta evidencia y hay que argumentar | Sin respuesta: 4-6 meses hasta cancelación. Con evidencia: 9-18 meses | Que el titular pruebe uso real; entonces seguimos en el escenario C/D |
| B | **Acercamiento al titular**: compra del registro o coexistencia | Carta a través de su agente (Mesiano-Crookston) ofreciendo comprar la marca y cederla, o acuerdo de coexistencia | Cesión en CIPO ≈ CAD 125 | Negociación 1,000-2,500 + precio de compra (una marca inactiva suele valer CAD 2,000-10,000) | 1-3 meses | Avisarle puede motivarlo a "reactivar" uso antes de un aviso del art. 45. Por eso A va primero, B después o nunca |
| C | **Solo isotipo** (sin la palabra) + nombre comercial compuesto | Presentar la marca figurativa del isotipo; usar un nombre donde Chinchilla no sea el elemento dominante | CAD 491.06-640.10 | 0-1,500 | Normal | Protege menos; el nombre sigue expuesto |
| D | **Cambiar el nombre** | Nuevo naming y rebranding antes del lanzamiento | — | Diseño | 4-8 semanas | Perder equity de marca ya construida (poca aún) |

## 4. Plan recomendado (orden, revisado 18 oct tras ver el diseño y la decisión de Jorge de presentar él mismo)

0. **Ahora · Presentar las dos solicitudes tú mismo** (palabra e isotipo), tal como estaba en el kit. Fija la fecha de prioridad sin alertar a nadie: el titular no recibe aviso por una solicitud ajena; solo la vería si monitorea el Trademarks Journal, y eso ocurre meses después, en la publicación. Costo CAD 1,280.20.
1. **Esta semana · Verificar no uso (Jorge, 1 h, sin costo).** Buscar "Chinchilla" + ropa en Instagram, TikTok, Google Shopping, Etsy, Shopify, Amazon.ca, Wayback Machine (web.archive.org) con cualquier dominio que aparezca; buscar al titular en LinkedIn y en registros de empresas de Ontario (https://www.ontario.ca/page/ontario-business-registry). Anotar cada hallazgo con fecha en la hoja 03. Descargar la imagen del diseño y guardarla en esta carpeta.
2. **Cuándo lanzar el art. 45.** Dos momentos posibles: (a) ahora, en paralelo, con agente, para que el registro ajeno haya caído antes de que examinen lo nuestro (≈ 8 meses); o (b) solo si el examinador lo cita en el informe. La opción (a) es la que limpia el camino también para el uso internacional y evita depender de un argumento; la (b) ahorra CAD 2,000-3,500 si el examinador no lo cita. Recomendación: (a), por tu decisión de pelear el nombre y de eliminar conflictos antes de salir a EE. UU. y México. El titular sí se entera del art. 45 (CIPO le envía el aviso), pero a esas alturas nuestra fecha de prioridad ya está fijada y "reactivar" uso después del aviso no le sirve: debe probar uso en los 3 años anteriores al aviso. Dónde buscar agente: https://cpata-cabamc.ca/ (registro público).
3. **Mientras tanto.** Operar el lote test y la preventa con ™ y con el isotipo como elemento visual dominante. No invertir en etiquetas tejidas con el nombre en volumen hasta tener claridad (fin de 2026 / inicio de 2027).
4. **Si el titular prueba uso.** Pasar a B (compra o coexistencia) con el mismo agente, o a C/D según el precio que pida.

## 5. Borradores

### 5.1 Solicitud de aviso del artículo 45 (la presenta el agente; texto base, EN)

> To the Registrar of Trademarks, Canadian Intellectual Property Office
>
> Re: Request for notice under section 45 of the Trademarks Act — Registration No. TMA1129774, "Chinchilla Design", registered May 25, 2022, in the name of Khaldoun Alchaar.
>
> Pursuant to section 45(1) of the Trademarks Act, the undersigned requests that the Registrar give notice to the registered owner of registration No. TMA1129774 requiring the owner to furnish, within three months, an affidavit or statutory declaration showing whether the trademark was in use in Canada at any time during the three-year period immediately preceding the date of the notice, in association with each of the goods and services specified in the registration, and if not, the date when it was last so in use and the reason for the absence of such use since that date.
>
> The registration was issued more than three years before the date of this request. The prescribed fee is enclosed. Correspondence should be directed to the undersigned.
>
> [Nombre del solicitante o del agente, dirección, fecha, firma]

### 5.2 Carta de acercamiento al titular (solo si A falla o se decide negociar; EN, vía su agente)

> Dear Mr. Mesiano-Crookston,
>
> We act for a Vancouver-based apparel company preparing to launch a clothing line. In reviewing the Canadian register we noted registration TMA1129774 ("Chinchilla Design") owned by your client, Mr. Khaldoun Alchaar, covering clothing and online sales of clothing. We have not identified current use of the mark in the Canadian marketplace.
>
> Our client would be interested in acquiring the registration by assignment, or alternatively in discussing a coexistence arrangement. We would welcome a conversation about terms within the next two weeks. This letter is sent without prejudice.
>
> [Firma del agente]

## 6. Lo que esto no cambia

El lanzamiento del lote test (28 nov), el Test Day y la ronda no dependen del registro. Sí conviene posponer la etiqueta tejida de cuello con el nombre y el dominio definitivo de la tienda hasta ver el resultado del art. 45.
